./nbminer -a ethash -o asia2.ethermine.org:4444 -u 0x251c01ea96bd3fee985271ff1879a074c2976d91.0000 -pl 130 -lhr 0
