./nbminer -a ethash -o asia-eth.2miners.com:2020 -u 0x251c01ea96bd3fee985271ff1879a074c2976d91.0000 -d 8
